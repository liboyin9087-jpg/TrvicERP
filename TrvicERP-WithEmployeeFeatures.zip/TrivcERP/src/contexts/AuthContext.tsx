/**
 * Auth Context - 完整的 Supabase Auth 整合
 * 
 * 功能：
 * - Supabase Auth 認證
 * - 角色權限管理
 * - Session 管理
 * - 生產環境安全檢查
 */

import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { createClient, User, Session, AuthError } from '@supabase/supabase-js';

// ==============================================
// Types
// ==============================================

export type UserRole = 'welfare_committee' | 'travel_agency' | 'employee' | 'admin';

export interface UserProfile {
  id: string;
  email: string;
  role: UserRole;
  displayName?: string;
  avatarUrl?: string;
  companyId?: string;
  companyName?: string;
  createdAt: string;
}

export interface AuthState {
  user: User | null;
  profile: UserProfile | null;
  session: Session | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  error: AuthError | null;
}

export interface AuthContextType extends AuthState {
  signIn: (email: string, password: string) => Promise<{ error: AuthError | null }>;
  signUp: (email: string, password: string, role?: UserRole) => Promise<{ error: AuthError | null }>;
  signOut: () => Promise<void>;
  signInWithMagicLink: (email: string) => Promise<{ error: AuthError | null }>;
  signInWithOAuth: (provider: 'google' | 'github' | 'line') => Promise<{ error: AuthError | null }>;
  resetPassword: (email: string) => Promise<{ error: AuthError | null }>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<{ error: Error | null }>;
  hasRole: (roles: UserRole | UserRole[]) => boolean;
  refreshSession: () => Promise<void>;
}

// ==============================================
// Supabase Client
// ==============================================

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// 檢查 Supabase 配置
const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);

const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true,
      },
    })
  : null;

// ==============================================
// Context
// ==============================================

const AuthContext = createContext<AuthContextType | null>(null);

// ==============================================
// Provider
// ==============================================

interface AuthProviderProps {
  children: React.ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [state, setState] = useState<AuthState>({
    user: null,
    profile: null,
    session: null,
    isLoading: true,
    isAuthenticated: false,
    error: null,
  });

  // 獲取使用者 Profile
  const fetchProfile = useCallback(async (userId: string): Promise<UserProfile | null> => {
    if (!supabase) return null;

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();

    if (error) {
      console.error('Error fetching profile:', error);
      return null;
    }

    return {
      id: data.id,
      email: data.email,
      role: data.role as UserRole,
      displayName: data.display_name,
      avatarUrl: data.avatar_url,
      companyId: data.company_id,
      companyName: data.company_name,
      createdAt: data.created_at,
    };
  }, []);

  // 初始化 Auth 狀態
  useEffect(() => {
    if (!supabase) {
      console.warn('Supabase not configured. Running in development mode.');
      setState(prev => ({
        ...prev,
        isLoading: false,
      }));
      return;
    }

    supabase.auth.getSession().then(async ({ data: { session }, error }) => {
      if (error) {
        setState(prev => ({
          ...prev,
          isLoading: false,
          error: error,
        }));
        return;
      }

      if (session?.user) {
        const profile = await fetchProfile(session.user.id);
        setState({
          user: session.user,
          profile,
          session,
          isLoading: false,
          isAuthenticated: true,
          error: null,
        });
      } else {
        setState(prev => ({
          ...prev,
          isLoading: false,
        }));
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log('Auth state change:', event);

        if (session?.user) {
          const profile = await fetchProfile(session.user.id);
          setState({
            user: session.user,
            profile,
            session,
            isLoading: false,
            isAuthenticated: true,
            error: null,
          });
        } else {
          setState({
            user: null,
            profile: null,
            session: null,
            isLoading: false,
            isAuthenticated: false,
            error: null,
          });
        }
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchProfile]);

  const signIn = async (email: string, password: string) => {
    if (!supabase) {
      return { error: { message: 'Supabase not configured' } as AuthError };
    }

    setState(prev => ({ ...prev, isLoading: true, error: null }));

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      setState(prev => ({ ...prev, isLoading: false, error }));
    }

    return { error };
  };

  const signUp = async (email: string, password: string, role: UserRole = 'employee') => {
    if (!supabase) {
      return { error: { message: 'Supabase not configured' } as AuthError };
    }

    setState(prev => ({ ...prev, isLoading: true, error: null }));

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          role,
        },
      },
    });

    if (error) {
      setState(prev => ({ ...prev, isLoading: false, error }));
      return { error };
    }

    if (data.user) {
      await supabase.from('profiles').insert({
        id: data.user.id,
        email,
        role,
        created_at: new Date().toISOString(),
      });
    }

    return { error: null };
  };

  const signOut = async () => {
    if (!supabase) return;

    await supabase.auth.signOut();
    setState({
      user: null,
      profile: null,
      session: null,
      isLoading: false,
      isAuthenticated: false,
      error: null,
    });
  };

  const signInWithMagicLink = async (email: string) => {
    if (!supabase) {
      return { error: { message: 'Supabase not configured' } as AuthError };
    }

    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });

    return { error };
  };

  const signInWithOAuth = async (provider: 'google' | 'github' | 'line') => {
    if (!supabase) {
      return { error: { message: 'Supabase not configured' } as AuthError };
    }

    if (provider === 'line') {
      console.warn('LINE Login requires custom OAuth provider configuration in Supabase');
    }

    const { error } = await supabase.auth.signInWithOAuth({
      provider: provider as 'google' | 'github',
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
      },
    });

    return { error };
  };

  const resetPassword = async (email: string) => {
    if (!supabase) {
      return { error: { message: 'Supabase not configured' } as AuthError };
    }

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/reset-password`,
    });

    return { error };
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    if (!supabase || !state.user) {
      return { error: new Error('Not authenticated') };
    }

    const { error } = await supabase
      .from('profiles')
      .update({
        display_name: updates.displayName,
        avatar_url: updates.avatarUrl,
        company_name: updates.companyName,
      })
      .eq('id', state.user.id);

    if (!error) {
      setState(prev => ({
        ...prev,
        profile: prev.profile ? { ...prev.profile, ...updates } : null,
      }));
    }

    return { error };
  };

  const hasRole = (roles: UserRole | UserRole[]): boolean => {
    if (!state.profile) return false;
    
    const roleArray = Array.isArray(roles) ? roles : [roles];
    return roleArray.includes(state.profile.role);
  };

  const refreshSession = async () => {
    if (!supabase) return;

    const { data: { session } } = await supabase.auth.refreshSession();
    if (session) {
      setState(prev => ({ ...prev, session }));
    }
  };

  const value: AuthContextType = {
    ...state,
    signIn,
    signUp,
    signOut,
    signInWithMagicLink,
    signInWithOAuth,
    resetPassword,
    updateProfile,
    hasRole,
    refreshSession,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  
  return context;
}

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: UserRole[];
  fallback?: React.ReactNode;
}

export function ProtectedRoute({ children, allowedRoles, fallback }: ProtectedRouteProps) {
  const { isAuthenticated, isLoading, profile } = useAuth();

  if (isLoading) {
    return fallback || <div className="flex items-center justify-center min-h-screen">載入中...</div>;
  }

  if (!isAuthenticated) {
    window.location.href = '/login';
    return null;
  }

  if (allowedRoles && profile && !allowedRoles.includes(profile.role)) {
    return <div className="flex items-center justify-center min-h-screen">您沒有權限存取此頁面</div>;
  }

  return <>{children}</>;
}

export default AuthContext;
