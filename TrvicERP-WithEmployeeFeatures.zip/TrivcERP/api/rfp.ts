// =====================================================
// TravelCanvas - RFP API Endpoint (Vercel Serverless)
// 處理 RFP CRUD 操作
// =====================================================

import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

function getSupabase() {
  if (!supabaseUrl || !supabaseServiceKey) {
    return null;
  }
  return createClient(supabaseUrl, supabaseServiceKey);
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const supabase = getSupabase();
  
  if (!supabase) {
    // Return mock data if Supabase is not configured
    return handleMockMode(req, res);
  }

  try {
    switch (req.method) {
      case 'GET':
        return await handleGet(req, res, supabase);
      case 'POST':
        return await handlePost(req, res, supabase);
      case 'PUT':
        return await handlePut(req, res, supabase);
      case 'DELETE':
        return await handleDelete(req, res, supabase);
      default:
        return res.status(405).json({ error: 'Method not allowed' });
    }
  } catch (error: any) {
    console.error('API Error:', error);
    return res.status(500).json({ error: error.message || 'Internal server error' });
  }
}

async function handleGet(req: VercelRequest, res: VercelResponse, supabase: any) {
  const { id, status, shareCode } = req.query;

  // Get single RFP by ID
  if (id) {
    const { data, error } = await supabase
      .from('rfps')
      .select('*, quotes(*)')
      .eq('id', id)
      .single();

    if (error) return res.status(404).json({ error: 'RFP not found' });
    return res.status(200).json({ data });
  }

  // Get RFP by share code (for external access)
  if (shareCode) {
    const { data, error } = await supabase
      .from('rfps')
      .select('*')
      .eq('share_code', shareCode)
      .eq('status', 'open')
      .single();

    if (error) return res.status(404).json({ error: 'RFP not found or not open' });
    return res.status(200).json({ data });
  }

  // List RFPs with optional status filter
  let query = supabase.from('rfps').select('*').order('created_at', { ascending: false });
  
  if (status) {
    query = query.eq('status', status);
  }

  const { data, error } = await query;
  
  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json({ data });
}

async function handlePost(req: VercelRequest, res: VercelResponse, supabase: any) {
  const body = req.body;

  // Validate required fields
  const requiredFields = ['company_name', 'contact_person', 'contact_email', 'headcount', 'budget_min', 'budget_max', 'destination', 'duration_days', 'deadline'];
  
  for (const field of requiredFields) {
    if (!body[field]) {
      return res.status(400).json({ error: `Missing required field: ${field}` });
    }
  }

  const { data, error } = await supabase
    .from('rfps')
    .insert({
      company_name: body.company_name,
      contact_person: body.contact_person,
      contact_email: body.contact_email,
      contact_phone: body.contact_phone,
      headcount: body.headcount,
      budget_min: body.budget_min,
      budget_max: body.budget_max,
      destination: body.destination,
      duration_days: body.duration_days,
      departure_date: body.departure_date,
      special_requirements: body.special_requirements || [],
      custom_requirements: body.custom_requirements,
      deadline: body.deadline,
      status: body.status || 'draft',
      created_by: body.created_by
    })
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  return res.status(201).json({ data });
}

async function handlePut(req: VercelRequest, res: VercelResponse, supabase: any) {
  const { id } = req.query;
  const body = req.body;

  if (!id) {
    return res.status(400).json({ error: 'Missing RFP ID' });
  }

  const { data, error } = await supabase
    .from('rfps')
    .update({
      ...body,
      updated_at: new Date().toISOString()
    })
    .eq('id', id)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json({ data });
}

async function handleDelete(req: VercelRequest, res: VercelResponse, supabase: any) {
  const { id } = req.query;

  if (!id) {
    return res.status(400).json({ error: 'Missing RFP ID' });
  }

  const { error } = await supabase
    .from('rfps')
    .delete()
    .eq('id', id);

  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json({ success: true });
}

function handleMockMode(req: VercelRequest, res: VercelResponse) {
  // Return mock data for development without Supabase
  const mockRFPs = [
    {
      id: 'mock-rfp-1',
      company_name: '台積電',
      contact_person: '王小明',
      contact_email: 'wang@tsmc.com',
      headcount: 50,
      budget_min: 25000,
      budget_max: 35000,
      destination: '日本',
      duration_days: 5,
      deadline: '2025-01-15',
      status: 'open',
      created_at: new Date().toISOString()
    },
    {
      id: 'mock-rfp-2',
      company_name: '國泰人壽',
      contact_person: '林美華',
      contact_email: 'lin@cathaylife.com',
      headcount: 80,
      budget_min: 30000,
      budget_max: 45000,
      destination: '韓國',
      duration_days: 6,
      deadline: '2025-02-01',
      status: 'open',
      created_at: new Date().toISOString()
    }
  ];

  if (req.method === 'GET') {
    return res.status(200).json({ data: mockRFPs, mock: true });
  }

  if (req.method === 'POST') {
    const newRFP = {
      id: `mock-rfp-${Date.now()}`,
      ...req.body,
      created_at: new Date().toISOString()
    };
    return res.status(201).json({ data: newRFP, mock: true });
  }

  return res.status(200).json({ success: true, mock: true });
}
