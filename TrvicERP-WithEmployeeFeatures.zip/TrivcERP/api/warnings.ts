// =====================================================
// TravelCanvas - Warning Database API (Vercel Serverless)
// 處理反雷資料庫 CRUD 操作
// =====================================================

import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

function getSupabase() {
  if (!supabaseUrl || !supabaseServiceKey) {
    return null;
  }
  return createClient(supabaseUrl, supabaseServiceKey);
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const supabase = getSupabase();
  
  if (!supabase) {
    return handleMockMode(req, res);
  }

  try {
    switch (req.method) {
      case 'GET':
        return await handleGet(req, res, supabase);
      case 'POST':
        return await handlePost(req, res, supabase);
      case 'PUT':
        return await handlePut(req, res, supabase);
      default:
        return res.status(405).json({ error: 'Method not allowed' });
    }
  } catch (error: any) {
    console.error('Warning API Error:', error);
    return res.status(500).json({ error: error.message || 'Internal server error' });
  }
}

async function handleGet(req: VercelRequest, res: VercelResponse, supabase: any) {
  const { id, severity, supplierType, verified, search, limit = 50 } = req.query;

  // Get single warning by ID
  if (id) {
    const { data, error } = await supabase
      .from('warning_reports')
      .select('*')
      .eq('id', id)
      .single();

    if (error) return res.status(404).json({ error: 'Warning not found' });
    return res.status(200).json({ data });
  }

  // List warnings with filters
  let query = supabase
    .from('warning_reports')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(Number(limit));

  if (severity) {
    query = query.eq('severity', severity);
  }

  if (supplierType) {
    query = query.eq('supplier_type', supplierType);
  }

  if (verified !== undefined) {
    query = query.eq('verified', verified === 'true');
  }

  if (search) {
    query = query.or(`supplier_name.ilike.%${search}%,issue_title.ilike.%${search}%`);
  }

  const { data, error } = await query;
  
  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json({ data });
}

async function handlePost(req: VercelRequest, res: VercelResponse, supabase: any) {
  const { action } = req.query;

  // Handle upvote/downvote
  if (action === 'vote') {
    return await handleVote(req, res, supabase);
  }

  // Create new warning
  const body = req.body;

  const requiredFields = ['supplier_name', 'supplier_type', 'severity', 'issue_title', 'issue_description'];
  
  for (const field of requiredFields) {
    if (!body[field]) {
      return res.status(400).json({ error: `Missing required field: ${field}` });
    }
  }

  const { data, error } = await supabase
    .from('warning_reports')
    .insert({
      supplier_name: body.supplier_name,
      supplier_type: body.supplier_type,
      location: body.location,
      city: body.city,
      country: body.country || 'Japan',
      severity: body.severity,
      issue_title: body.issue_title,
      issue_description: body.issue_description,
      incident_date: body.incident_date,
      evidence_urls: body.evidence_urls || [],
      reported_by: body.reported_by,
      reporter_agency: body.reporter_agency,
      tags: body.tags || [],
      report_count: 1,
      verified: false,
      resolution_status: 'open'
    })
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  return res.status(201).json({ data });
}

async function handleVote(req: VercelRequest, res: VercelResponse, supabase: any) {
  const { warningId, voterId, voteType } = req.body;

  if (!warningId || !voterId || !voteType) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  if (!['up', 'down'].includes(voteType)) {
    return res.status(400).json({ error: 'Invalid vote type' });
  }

  // Check existing vote
  const { data: existingVote } = await supabase
    .from('warning_votes')
    .select('*')
    .eq('warning_id', warningId)
    .eq('voter_id', voterId)
    .single();

  if (existingVote) {
    if (existingVote.vote_type === voteType) {
      // Remove vote
      await supabase
        .from('warning_votes')
        .delete()
        .eq('id', existingVote.id);
      
      return res.status(200).json({ message: 'Vote removed' });
    } else {
      // Change vote
      await supabase
        .from('warning_votes')
        .update({ vote_type: voteType })
        .eq('id', existingVote.id);
      
      return res.status(200).json({ message: 'Vote changed' });
    }
  }

  // New vote
  const { error } = await supabase
    .from('warning_votes')
    .insert({
      warning_id: warningId,
      voter_id: voterId,
      vote_type: voteType
    });

  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json({ message: 'Vote recorded' });
}

async function handlePut(req: VercelRequest, res: VercelResponse, supabase: any) {
  const { id } = req.query;
  const body = req.body;

  if (!id) {
    return res.status(400).json({ error: 'Missing warning ID' });
  }

  const { data, error } = await supabase
    .from('warning_reports')
    .update({
      ...body,
      updated_at: new Date().toISOString()
    })
    .eq('id', id)
    .select()
    .single();

  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json({ data });
}

function handleMockMode(req: VercelRequest, res: VercelResponse) {
  const mockWarnings = [
    {
      id: 'mock-warning-1',
      supplier_name: '淺草某飯店',
      supplier_type: 'hotel',
      location: '淺草',
      severity: 'high',
      issue_title: '設施老舊與照片不符',
      issue_description: '實際房間設施老舊，與網站照片嚴重不符，空調故障且隔音差。',
      report_count: 5,
      upvotes: 12,
      downvotes: 2,
      trust_score: 0.86,
      verified: true,
      resolution_status: 'open',
      created_at: new Date().toISOString()
    },
    {
      id: 'mock-warning-2',
      supplier_name: '某團餐餐廳',
      supplier_type: 'restaurant',
      location: '新宿',
      severity: 'medium',
      issue_title: '出餐速度慢影響行程',
      issue_description: '團餐等待時間過長，40人團體等了近1小時才上菜，嚴重影響後續行程。',
      report_count: 3,
      upvotes: 8,
      downvotes: 1,
      trust_score: 0.89,
      verified: false,
      resolution_status: 'investigating',
      created_at: new Date().toISOString()
    }
  ];

  if (req.method === 'GET') {
    return res.status(200).json({ data: mockWarnings, mock: true });
  }

  if (req.method === 'POST') {
    const newWarning = {
      id: `mock-warning-${Date.now()}`,
      ...req.body,
      report_count: 1,
      upvotes: 0,
      downvotes: 0,
      trust_score: 0.5,
      verified: false,
      resolution_status: 'open',
      created_at: new Date().toISOString()
    };
    return res.status(201).json({ data: newWarning, mock: true });
  }

  return res.status(200).json({ success: true, mock: true });
}
