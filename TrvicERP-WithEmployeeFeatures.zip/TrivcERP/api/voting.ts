// =====================================================
// TravelCanvas - Voting API Endpoint (Vercel Serverless)
// 處理投票 CRUD 操作
// =====================================================

import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

function getSupabase() {
  if (!supabaseUrl || !supabaseServiceKey) {
    return null;
  }
  return createClient(supabaseUrl, supabaseServiceKey);
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const supabase = getSupabase();
  
  if (!supabase) {
    return res.status(503).json({ 
      error: 'Database not configured',
      message: 'Please use localStorage-based voting in demo mode'
    });
  }

  const { action } = req.query;

  try {
    switch (action) {
      case 'list':
        return await listPolls(req, res, supabase);
      case 'get':
        return await getPoll(req, res, supabase);
      case 'create':
        return await createPoll(req, res, supabase);
      case 'vote':
        return await castVote(req, res, supabase);
      case 'delete':
        return await deletePoll(req, res, supabase);
      default:
        return res.status(400).json({ error: 'Invalid action' });
    }
  } catch (error: any) {
    console.error('Voting API Error:', error);
    return res.status(500).json({ error: error.message || 'Internal server error' });
  }
}

async function listPolls(_req: VercelRequest, res: VercelResponse, supabase: any) {
  const { data, error } = await supabase
    .from('vote_polls')
    .select(`
      *,
      vote_options (*)
    `)
    .order('created_at', { ascending: false });

  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json({ data });
}

async function getPoll(req: VercelRequest, res: VercelResponse, supabase: any) {
  const { id, voterId } = req.query;

  if (!id) {
    return res.status(400).json({ error: 'Missing poll ID' });
  }

  const { data: poll, error: pollError } = await supabase
    .from('vote_polls')
    .select(`
      *,
      vote_options (*)
    `)
    .eq('id', id)
    .single();

  if (pollError) return res.status(404).json({ error: 'Poll not found' });

  // Get voter's choice if voterId is provided
  let voterChoice = null;
  if (voterId) {
    const { data: vote } = await supabase
      .from('vote_records')
      .select('option_id')
      .eq('poll_id', id)
      .eq('voter_id', voterId)
      .single();
    
    voterChoice = vote?.option_id || null;
  }

  return res.status(200).json({ data: { ...poll, voterChoice } });
}

async function createPoll(req: VercelRequest, res: VercelResponse, supabase: any) {
  const { title, description, deadline, createdByRole, options } = req.body;

  if (!title || !deadline || !options || options.length < 2) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  // Create poll
  const { data: poll, error: pollError } = await supabase
    .from('vote_polls')
    .insert({
      title,
      description,
      deadline,
      created_by_role: createdByRole || 'welfare_committee',
      status: 'active'
    })
    .select()
    .single();

  if (pollError) return res.status(500).json({ error: pollError.message });

  // Create options
  const optionsToInsert = options.filter(Boolean).map((label: string) => ({
    poll_id: poll.id,
    label,
    vote_count: 0
  }));

  const { error: optionsError } = await supabase
    .from('vote_options')
    .insert(optionsToInsert);

  if (optionsError) {
    // Rollback poll creation
    await supabase.from('vote_polls').delete().eq('id', poll.id);
    return res.status(500).json({ error: optionsError.message });
  }

  // Fetch complete poll with options
  const { data: completePoll } = await supabase
    .from('vote_polls')
    .select(`
      *,
      vote_options (*)
    `)
    .eq('id', poll.id)
    .single();

  return res.status(201).json({ data: completePoll });
}

async function castVote(req: VercelRequest, res: VercelResponse, supabase: any) {
  const { pollId, voterId, optionId } = req.body;

  if (!pollId || !voterId || !optionId) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  // Check if already voted
  const { data: existingVote } = await supabase
    .from('vote_records')
    .select('id, option_id')
    .eq('poll_id', pollId)
    .eq('voter_id', voterId)
    .single();

  if (existingVote) {
    if (existingVote.option_id === optionId) {
      return res.status(200).json({ message: 'Already voted for this option' });
    }

    // Change vote: decrement old, increment new
    await supabase.rpc('decrement_vote_count', { opt_id: existingVote.option_id });
    
    await supabase
      .from('vote_records')
      .update({ option_id: optionId })
      .eq('id', existingVote.id);
    
    await supabase.rpc('increment_vote_count', { opt_id: optionId });

    return res.status(200).json({ message: 'Vote changed successfully' });
  }

  // New vote
  const { error: voteError } = await supabase
    .from('vote_records')
    .insert({
      poll_id: pollId,
      voter_id: voterId,
      option_id: optionId
    });

  if (voteError) return res.status(500).json({ error: voteError.message });

  // Increment vote count
  await supabase.rpc('increment_vote_count', { opt_id: optionId });

  return res.status(200).json({ message: 'Vote recorded successfully' });
}

async function deletePoll(req: VercelRequest, res: VercelResponse, supabase: any) {
  const { id } = req.query;

  if (!id) {
    return res.status(400).json({ error: 'Missing poll ID' });
  }

  const { error } = await supabase
    .from('vote_polls')
    .delete()
    .eq('id', id);

  if (error) return res.status(500).json({ error: error.message });
  return res.status(200).json({ success: true });
}
