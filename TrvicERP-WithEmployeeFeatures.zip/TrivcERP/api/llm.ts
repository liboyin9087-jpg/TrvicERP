/**
 * Vercel Serverless Function: /api/llm
 * 
 * 安全的 LLM Proxy - 支援多種 Provider
 * Purpose: Keep API keys OFF the client side
 * 
 * Supported Providers:
 * - openai (default)
 * - anthropic
 * - ollama-remote (self-hosted Ollama)
 * - github-models
 * - huggingface
 * 
 * Request JSON: { 
 *   "messages": [{"role":"user","content":"..."}, ...], 
 *   "model"?: string,
 *   "provider"?: string
 * }
 * Response JSON: { "text": string }
 */

import { z } from 'zod';
import type { VercelRequest, VercelResponse } from '@vercel/node';

// ==============================================
// Schema Validation
// ==============================================

const MessageSchema = z.object({
  role: z.enum(['system', 'user', 'assistant']),
  content: z.string().min(1).max(8000),
});

const BodySchema = z.object({
  provider: z.enum(['openai', 'anthropic', 'ollama-remote', 'github-models', 'huggingface']).optional().default('openai'),
  model: z.string().optional(),
  messages: z.array(MessageSchema).min(1).max(30),
  temperature: z.number().min(0).max(2).optional(),
  max_tokens: z.number().min(1).max(4096).optional(),
});

// ==============================================
// Rate Limiting (Simple in-memory implementation)
// For production, use Upstash Redis or similar
// ==============================================

const rateLimitMap = new Map<string, { count: number; resetTime: number }>();
const RATE_LIMIT_MAX = 30; // requests per window
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute

function checkRateLimit(identifier: string): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const record = rateLimitMap.get(identifier);

  if (!record || now > record.resetTime) {
    rateLimitMap.set(identifier, { count: 1, resetTime: now + RATE_LIMIT_WINDOW });
    return { allowed: true, remaining: RATE_LIMIT_MAX - 1 };
  }

  if (record.count >= RATE_LIMIT_MAX) {
    return { allowed: false, remaining: 0 };
  }

  record.count++;
  return { allowed: true, remaining: RATE_LIMIT_MAX - record.count };
}

// ==============================================
// Provider Configurations
// ==============================================

interface ProviderConfig {
  baseURL: string;
  defaultModel: string;
  getHeaders: () => Record<string, string>;
  formatRequest: (messages: z.infer<typeof MessageSchema>[], model: string, options: RequestOptions) => object;
  parseResponse: (data: any) => string;
}

interface RequestOptions {
  temperature?: number;
  max_tokens?: number;
}

const getProviderConfig = (provider: string): ProviderConfig => {
  switch (provider) {
    case 'openai':
      return {
        baseURL: 'https://api.openai.com/v1/chat/completions',
        defaultModel: process.env.OPENAI_MODEL || 'gpt-4o-mini',
        getHeaders: () => ({
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        }),
        formatRequest: (messages, model, options) => ({
          model,
          messages,
          temperature: options.temperature ?? 0.3,
          max_tokens: options.max_tokens ?? 1000,
        }),
        parseResponse: (data) => data?.choices?.[0]?.message?.content ?? '',
      };

    case 'anthropic':
      return {
        baseURL: 'https://api.anthropic.com/v1/messages',
        defaultModel: process.env.ANTHROPIC_MODEL || 'claude-3-haiku-20240307',
        getHeaders: () => ({
          'Content-Type': 'application/json',
          'x-api-key': process.env.ANTHROPIC_API_KEY || '',
          'anthropic-version': '2023-06-01',
        }),
        formatRequest: (messages, model, options) => {
          const systemMsg = messages.find(m => m.role === 'system');
          const otherMsgs = messages.filter(m => m.role !== 'system');
          return {
            model,
            max_tokens: options.max_tokens ?? 1000,
            system: systemMsg?.content || 'You are a helpful travel operations assistant.',
            messages: otherMsgs.map(m => ({ role: m.role, content: m.content })),
          };
        },
        parseResponse: (data) => data?.content?.[0]?.text ?? '',
      };

    case 'ollama-remote':
      return {
        baseURL: process.env.OLLAMA_BASE_URL || 'http://localhost:11434/api/chat',
        defaultModel: process.env.OLLAMA_MODEL || 'llama3.2:3b',
        getHeaders: () => ({
          'Content-Type': 'application/json',
        }),
        formatRequest: (messages, model, options) => ({
          model,
          messages,
          stream: false,
          options: {
            temperature: options.temperature ?? 0.3,
            num_predict: options.max_tokens ?? 1000,
          },
        }),
        parseResponse: (data) => data?.message?.content ?? '',
      };

    case 'github-models':
      return {
        baseURL: 'https://models.inference.ai.azure.com/chat/completions',
        defaultModel: process.env.GITHUB_MODEL || 'meta-llama/Llama-3.2-11B-Vision-Instruct',
        getHeaders: () => ({
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.GITHUB_TOKEN}`,
        }),
        formatRequest: (messages, model, options) => ({
          model,
          messages,
          temperature: options.temperature ?? 0.3,
          max_tokens: options.max_tokens ?? 1000,
        }),
        parseResponse: (data) => data?.choices?.[0]?.message?.content ?? '',
      };

    case 'huggingface':
      return {
        baseURL: `https://api-inference.huggingface.co/models/${process.env.HF_MODEL || 'meta-llama/Llama-3.2-3B-Instruct'}`,
        defaultModel: process.env.HF_MODEL || 'meta-llama/Llama-3.2-3B-Instruct',
        getHeaders: () => ({
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.HF_API_KEY}`,
        }),
        formatRequest: (messages, _model, options) => {
          const prompt = messages.map(m => `${m.role}: ${m.content}`).join('\n');
          return {
            inputs: prompt,
            parameters: {
              max_new_tokens: options.max_tokens ?? 500,
              temperature: options.temperature ?? 0.3,
              return_full_text: false,
            },
          };
        },
        parseResponse: (data) => data?.[0]?.generated_text ?? '',
      };

    default:
      throw new Error(`Unknown provider: ${provider}`);
  }
};

// ==============================================
// API Key Validation
// ==============================================

function validateProviderApiKey(provider: string): { valid: boolean; error?: string } {
  switch (provider) {
    case 'openai':
      if (!process.env.OPENAI_API_KEY) {
        return { valid: false, error: 'OPENAI_API_KEY is not configured' };
      }
      break;
    case 'anthropic':
      if (!process.env.ANTHROPIC_API_KEY) {
        return { valid: false, error: 'ANTHROPIC_API_KEY is not configured' };
      }
      break;
    case 'github-models':
      if (!process.env.GITHUB_TOKEN) {
        return { valid: false, error: 'GITHUB_TOKEN is not configured' };
      }
      break;
    case 'huggingface':
      if (!process.env.HF_API_KEY) {
        return { valid: false, error: 'HF_API_KEY is not configured' };
      }
      break;
    case 'ollama-remote':
      if (!process.env.OLLAMA_BASE_URL) {
        return { valid: false, error: 'OLLAMA_BASE_URL is not configured for remote Ollama' };
      }
      break;
  }
  return { valid: true };
}

// ==============================================
// Main Handler
// ==============================================

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // CORS Headers
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  // Rate Limiting
  const clientIP = (req.headers['x-forwarded-for'] as string)?.split(',')[0] || 'unknown';
  const rateLimitResult = checkRateLimit(clientIP);
  
  res.setHeader('X-RateLimit-Limit', RATE_LIMIT_MAX.toString());
  res.setHeader('X-RateLimit-Remaining', rateLimitResult.remaining.toString());

  if (!rateLimitResult.allowed) {
    return res.status(429).json({ 
      error: 'Rate limit exceeded', 
      message: 'Too many requests. Please try again later.',
      retryAfter: Math.ceil(RATE_LIMIT_WINDOW / 1000)
    });
  }

  try {
    const parsed = BodySchema.parse(req.body);
    const { provider, messages, temperature, max_tokens } = parsed;

    const keyValidation = validateProviderApiKey(provider);
    if (!keyValidation.valid) {
      return res.status(500).json({ error: keyValidation.error });
    }

    const config = getProviderConfig(provider);
    const model = parsed.model || config.defaultModel;

    const response = await fetch(config.baseURL, {
      method: 'POST',
      headers: config.getHeaders(),
      body: JSON.stringify(config.formatRequest(messages, model, { temperature, max_tokens })),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error(`[LLM Proxy] ${provider} error:`, errText.slice(0, 500));
      return res.status(502).json({ 
        error: 'Upstream LLM error', 
        provider,
        status: response.status,
        detail: errText.slice(0, 500) 
      });
    }

    const data = await response.json();
    const text = config.parseResponse(data);

    console.log(`[LLM Proxy] Success - Provider: ${provider}, Model: ${model}, Chars: ${text.length}`);

    return res.status(200).json({ 
      text,
      provider,
      model,
      usage: data.usage || null
    });

  } catch (e: any) {
    console.error('[LLM Proxy] Error:', e);
    
    if (e instanceof z.ZodError) {
      return res.status(400).json({ 
        error: 'Validation Error', 
        details: e.errors 
      });
    }

    return res.status(500).json({ 
      error: 'Internal Server Error', 
      message: e?.message || String(e) 
    });
  }
}
